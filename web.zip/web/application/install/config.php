<?php
return array(

	'view_replace_str' => array(
		'__ADDONS__'           => BASE_PATH . '/addons',
		'__PUBLIC__'           => BASE_PATH . '/public',
		'__STATIC__'           => BASE_PATH . '/application/admin/static',
		'__IMG__'              => BASE_PATH . '/application/admin/static/images',
		'__CSS__'              => BASE_PATH . '/application/admin/static/css',
		'__JS__'               => BASE_PATH . '/application/admin/static/js',
      '__IMG1__'              => BASE_PATH . '/application/admin/static/imgs',
		'__COMPANY__'          => '深圳瑞科软件有限公司',
		'__NAME__'             => '瑞科综合管理系统',
		'__COMPANY_WEBSITE__' => 'http://www.ruikesoft.com',
		'__WEBSITE__' => 'http://www.ruikesoft.com',
	),
);