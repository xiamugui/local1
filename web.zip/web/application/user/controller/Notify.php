<?php
namespace app\user\controller;
use app\common\controller\User;
use think\Db;
use think\Session;
use \think\Config;
use Qiniu\json_decode;
use mikkle\tp_wxpay;
use think\Controller;
class Notify extends Controller{
	
	
	
	  /**
     * 微信通知页面。
     */
    public function wxpayNotify(){
		$testxml = file_get_contents("php://input");
		$jsonxml = json_encode(simplexml_load_string($testxml, 'SimpleXMLElement', LIBXML_NOCDATA));
		
		$result = json_decode($jsonxml, true);
		
		$out_trade_no = $result['out_trade_no'];
		if($result['return_code'] == 'SUCCESS'){
			$orderArr= Db::name('payorder')->where(['order_no'=>$out_trade_no,'status'=>0])->find();
			$res= Db::name('admin')->where('id', $orderArr['uid'])->find();
			$newMoney=$res['money']+$orderArr['money'];
			Db::name('admin')->where('id', $orderArr['uid'])->update(['money'=>$newMoney]);
			Db::name('payorder')->where('order_no', $out_trade_no)->update(['status'=>1]);
			$data['owner']=$orderArr['uid'];
			$data['menoy']=(float)$orderArr['money'];
			$data['type']=2;
			$data['status']=1;
			$data['create_time']=time();
			$data['out_trade_no']=$out_trade_no;
			$data['oper']=$res['pid'];
			$data['balance']=(float)$newMoney;
			$data['deposit_type']=1;
			Db::name('tel_deposit')->insert($data);
			
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
}