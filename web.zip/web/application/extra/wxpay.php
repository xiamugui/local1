<?php

return [
    "default_options_name"=>"wxpay_options",
    "wxpay_options"=>[
        'appid'=>'wx52519322f09f0e02',
        'secret'=>'7ceedb0a5972fa2ae77216287bfe22b6',
        'mch_id'=>'1420926702',
        'key'=>'izpohwinvse5jfenjmyd1gawk4zstcs1',
    ],

];
